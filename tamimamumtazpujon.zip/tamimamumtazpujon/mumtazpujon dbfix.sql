-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 30 Jun 2020 pada 08.53
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mumtazpujon`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun`
--

CREATE TABLE `akun` (
  `ID` int(11) NOT NULL,
  `nama` varchar(10) NOT NULL DEFAULT '',
  `user` varchar(10) NOT NULL DEFAULT '',
  `pass` char(32) NOT NULL DEFAULT '',
  `type` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `akun`
--

INSERT INTO `akun` (`ID`, `nama`, `user`, `pass`, `type`) VALUES
(3, 'a', 'a', 'c4ca4238a0b923820dcc509a6f75849b', 1),
(4, 'sa', 'sa', 'c12e01f2a13ff5587e1e9e4aedb8242d', 2),
(5, 'hilmy', 'hilmy', 'c4ca4238a0b923820dcc509a6f75849b', 1),
(6, 'setya', 'setya', 'c4ca4238a0b923820dcc509a6f75849b', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `gejala`
--

CREATE TABLE `gejala` (
  `ID` int(11) NOT NULL,
  `nama` char(3) NOT NULL DEFAULT '',
  `pengertian` varchar(160) NOT NULL DEFAULT '',
  `a` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `gejala`
--

INSERT INTO `gejala` (`ID`, `nama`, `pengertian`, `a`) VALUES
(9, 'G01', 'kurang melihat (kabur) tidak mampu mengenali orang pada jarak 6 meter\r\n', 2),
(10, 'G02', 'kesulitan mengambil benda kecil di dekatnya\r\n', 2),
(11, 'G03', 'tidak dapat menulis mengikuti garis lurus\r\n', 2),
(12, 'G04', 'sering meraba dan tersandung waktu berjalan \r\n', 0),
(13, 'G05', 'bagian bola mata yang hitam berwarna keruh/bersisik/kering\r\n', 2),
(14, 'G06', 'mata bergoyang terus\r\n', 2),
(15, 'G07', 'peradangan hebat pada kedua bola mata\r\n', 2),
(16, 'G08', 'kerusakan nyata pada kedua bola mata\r\n', 2),
(17, 'G09', 'tidak dapat membedakan cahaya\r\n', 2),
(18, 'G10', 'sering memiringkan kepada dalam usaha mendengar\r\n', 0),
(19, 'G11', 'banyak perhatian terhadap getaran\r\n', 0),
(20, 'G12', 'tidak ada reaksi terhadap bunyi/suara di dekatnya\r\n', 0),
(21, 'G13', 'terlambat dalam perkembangan bahasa\r\n', 0),
(22, 'G14', 'sering menggunakan isyarat dalam berkomunikasi\r\n', 3),
(23, 'G15', 'kurang atau tidak tanggap bila diajak bicara\r\n', 3),
(24, 'G16', 'tidak mampu mendengar\r\n', 3),
(25, 'G17', 'memiliki iq 50-70\r\n', 3),
(26, 'G18', 'dua kali berturut turut tidak naik kelas\r\n', 3),
(27, 'G19', 'masih mampu membaca menulis dan berhitung sederhana\r\n', 3),
(28, 'G20', 'tida dapat berfikir secara abstrak\r\n', 3),
(29, 'G21', 'kurang perhatian terhadap lingkungan\r\n', 3),
(30, 'G22', 'sulit menyesuaikan diri dengan situasi (interaksi sosial(\r\n', 3),
(31, 'G23', 'memiliki iq 25-50\r\n', 3),
(32, 'G24', 'tidak dapat berfikir secara abstrak\r\n', 3),
(33, 'G25', 'hanya mampu membaca kalimat tunggal\r\n', 3),
(34, 'G26', 'mengalami kesulitan dalam berhitung sekalipun sederhana\r\n', 3),
(35, 'G27', 'perkembangan interaksi dan komunikasinya terlambat\r\n', 3),
(36, 'G28', 'mengalami kesulitan untuk beradaptasi dengan lingkungan yang baru (penyesuaian diri)\r\n', 3),
(37, 'G29', 'kurang mampu untuk mengurus diri sendiri\r\n', 3),
(38, 'G30', 'memiliki iq 25 kebawah\r\n', 3),
(39, 'G31', 'hanya mampu membaca satu kata\r\n', 3),
(40, 'G32', 'sama sekali tidak dapat berfikir secara abstrak\r\n', 3),
(41, 'G33', 'tidak dapat melakukan kontak sosial \r\n', 3),
(42, 'G34', 'tidak mampu mengurus diri sendiri\r\n', 3),
(43, 'G35', 'akan banyak bergantung pada bantuan orang lain\r\n', 3),
(44, 'G36', 'jari jari tangan kaku dan tidak dapat menggenggam\r\n', 3),
(45, 'G37', 'terdapat bagain anggota gerak yang tidak lengkap/tidak sempurna/lebih kecil dari biaanya\r\n', 3),
(46, 'G38', 'terdapat cacat pada alat gerak\r\n', 3),
(47, 'G39', 'kesulitan dalam melakukan gerakan (tidak sempurna, tidak lentur, dan tidak terkendali)\r\n', 3),
(48, 'G40', 'anggota gerak kaku, lemah, lumpuh dan layu\r\n', 3),
(49, 'G41', 'gangguan otak\r\n', 3),
(50, 'G42', 'gerak yang ditampilkan kekakuan atau tremor\r\n', 3),
(51, 'G43', 'mudah terangsang emosinya/emosional/mudah marah\r\n', 3),
(52, 'G44', 'menentang otoritas\r\n', 3),
(53, 'G45', 'sering melakukan tindakan agresif, merusak, menganggu\r\n', 3),
(54, 'G46', 'sering bertindak melanggar norma sosial/norma susila/ hukum dan agama\r\n', 3),
(55, 'G47', 'membaca pada usia lebih muda\r\n', 3),
(56, 'G48', 'membaca lebih cepat dan lebih banyak\r\n', 3),
(57, 'G49', 'memiliki perbendaharaan kata yang luas\r\n', 3),
(58, 'G50', 'mempunyai rasa ingin tahu yang kuat\r\n', 3),
(59, 'G51', 'mempunyai minat yang luas, juga terhadap masalah orang dewasa\r\n', 3),
(60, 'G52', 'mempunyai inisiatif dan dapat bekerja sendiri\r\n', 3),
(61, 'G53', 'menunjukan kesalahan (orisionalitas) dalam lingkungan verbal\r\n', 3),
(62, 'G54', 'memberi jawaban, jawaban yang baik\r\n', 3),
(63, 'G55', 'dapat memberikan banyak gagasan\r\n', 3),
(64, 'G56', 'luwes dalam berpikir\r\n', 2),
(65, 'G57', 'terbuka terhadap rangsangan rangsangan dari lingkungan\r\n', 2),
(66, 'G58', 'mempunyai pengamatan yang tajam\r\n', 0),
(67, 'G59', 'dapat berkonsentrasi dalam jangka waktu yang panjang terutama dalam tugas atau bidang yg diminati\r\n', 0),
(68, 'G60', 'berpikir kritis juga terhadap diri sendiri\r\n', 0),
(69, 'G61', 'senang mencoba hal hal yang baru\r\n', 0),
(70, 'G62', 'mempunyai daya abstraksi, konseptualisasi dan sintetis yang tinggi\r\n', 0),
(71, 'G63', 'senang terhadap kegiatan intelektual dan pemecahan masalah\r\n', 0),
(72, 'G64', 'cepat menangkap hubungan sebab akibat\r\n', 0),
(73, 'G65', 'mempunyai daya imajinasi yang kuat\r\n', 0),
(74, 'G66', 'mempunyai daya ingat yang kuat\r\n', 0),
(75, 'G67', 'daya tangkap terhadap pelajaran sangat lambat\r\n', 0),
(76, 'G68', 'sering lambat dalam menyelesaikan tugas akademik\r\n', 2),
(77, 'G69', 'rata rata prestasi belajar selalu rendah\r\n', 0),
(78, 'G70', 'perkembangan kemampuan membaca terlambat\r\n', 0),
(79, 'G71', 'kemampuan memahami isi bacaan rendah\r\n', 0),
(80, 'G72', 'kalau membaca sering banyak kesalahan\r\n', 0),
(81, 'G73', 'kalau menyali tulisan sering terlambat selesai\r\n', 0),
(82, 'G74', 'sering salah menulis / membaca huruf b dengan p, p dengan q, v dengan u, 2 dengan 5, 6 dengan 9\r\n', 0),
(83, 'G75', 'hasil tulisannya jelek dan hampir tidak terbaca\r\n', 0),
(84, 'G76', 'tulisannya banyak salah/terbalik/huruf hilang,\r\n', 0),
(85, 'G77', 'sulit menulis dengan lurus pada kertas bergaris\r\n', 0),
(86, 'G78', 'sulit membedakan tanda-tanda: +, -,x, :, <, >, =\r\n', 0),
(87, 'G79', 'sulit mengoperasikan hitungan/bilangan\r\n', 0),
(88, 'G80', 'sering salah membilang dengan urut\r\n', 0),
(89, 'G81', 'sering salah membedakan angka 9 dengan 6; 17 dengan 71, 2 dengan 5, 3 dengan 8 dan sebagainya\r\n', 0),
(90, 'G82', 'sulit membedakan bangun geometri\r\n', 0),
(91, 'G83', 'kesulitan mengenal dan merespon dengan emosi\r\n', 0),
(92, 'G84', 'tidak bisa menunjukan perbedaan ekspresi muka secara jelas\r\n', 0),
(93, 'G85', 'kurang memiliki perasaan dan empati\r\n', 0),
(94, 'G86', 'ekspresi emosi yang kaku\r\n', 0),
(95, 'G87', 'sering menunjukan perilaku yang bersifat stereotip\r\n', 0),
(96, 'G88', 'sulit untuk diajak berkomunikasi secara verbal\r\n', 0),
(97, 'G89', 'cenderung menyendiri\r\n', 0),
(98, 'G90', 'sering mengabaikan situasi disekeliling\r\n', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `konsultasi`
--

CREATE TABLE `konsultasi` (
  `IDk` int(11) NOT NULL,
  `hasil` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `konsultasi`
--

INSERT INTO `konsultasi` (`IDk`, `hasil`) VALUES
(1, 'low vision'),
(2, 'tunanetra'),
(5, 'kurang pendengaran'),
(6, 'tuli'),
(7, 'tunagrahita ringan'),
(8, 'tunagrahita sedang'),
(9, 'tunagrahita berat'),
(10, 'polio'),
(11, 'cerbal palcy'),
(12, 'tunalaras'),
(13, 'anak berbakat'),
(14, 'anak lamban belajar'),
(15, 'disleksia'),
(16, 'disgrafia'),
(17, 'diskalkulia'),
(18, 'autis');

-- --------------------------------------------------------

--
-- Struktur dari tabel `konsultasi_dtl`
--

CREATE TABLE `konsultasi_dtl` (
  `IDkd` int(11) NOT NULL DEFAULT '0',
  `IDg` int(11) NOT NULL DEFAULT '0',
  `cek` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `konsultasi_dtl`
--

INSERT INTO `konsultasi_dtl` (`IDkd`, `IDg`, `cek`) VALUES
(1, 15, 0),
(1, 11, 0),
(1, 10, 0),
(1, 14, 0),
(2, 17, 2),
(2, 16, 2),
(2, 10, 2),
(1, 13, 0),
(1, 12, 0),
(5, 19, 0),
(5, 18, 0),
(1, 9, 0),
(1, 16, 0),
(5, 20, 0),
(5, 21, 0),
(5, 22, 0),
(5, 23, 0),
(6, 24, 0),
(6, 20, 0),
(6, 19, 0),
(7, 25, 2),
(7, 26, 2),
(7, 27, 2),
(7, 28, 2),
(7, 29, 2),
(7, 30, 2),
(8, 31, 2),
(8, 32, 2),
(8, 33, 2),
(8, 34, 2),
(8, 35, 2),
(8, 36, 2),
(8, 37, 2),
(9, 38, 2),
(9, 39, 2),
(9, 40, 2),
(9, 41, 2),
(9, 42, 2),
(9, 43, 2),
(10, 44, 2),
(10, 45, 2),
(10, 46, 2),
(10, 47, 2),
(10, 48, 2),
(11, 44, 2),
(11, 45, 2),
(11, 46, 2),
(11, 47, 2),
(11, 48, 2),
(11, 49, 2),
(11, 50, 2),
(12, 51, 2),
(12, 52, 2),
(12, 53, 2),
(12, 54, 2),
(13, 55, 0),
(13, 56, 0),
(13, 57, 0),
(13, 58, 0),
(13, 59, 0),
(13, 60, 0),
(13, 61, 0),
(13, 62, 0),
(13, 63, 0),
(13, 64, 0),
(13, 65, 0),
(13, 66, 0),
(13, 67, 0),
(13, 68, 0),
(13, 69, 0),
(13, 70, 0),
(13, 71, 0),
(13, 72, 0),
(13, 73, 0),
(13, 74, 0),
(14, 75, 0),
(14, 76, 0),
(14, 77, 0),
(15, 78, 0),
(15, 79, 0),
(15, 80, 0),
(15, 82, 0),
(15, 89, 0),
(16, 85, 0),
(16, 84, 0),
(16, 83, 0),
(16, 82, 0),
(16, 81, 0),
(16, 80, 0),
(16, 86, 0),
(17, 82, 0),
(17, 86, 0),
(17, 87, 0),
(17, 88, 0),
(17, 89, 0),
(17, 90, 0),
(18, 91, 0),
(18, 92, 0),
(18, 93, 0),
(18, 94, 0),
(18, 95, 0),
(18, 96, 0),
(18, 97, 0),
(18, 98, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `log`
--

CREATE TABLE `log` (
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nama` varchar(30) NOT NULL DEFAULT '',
  `umur` int(11) NOT NULL DEFAULT '0',
  `diagnosa` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `log`
--

INSERT INTO `log` (`time`, `nama`, `umur`, `diagnosa`) VALUES
('2019-08-18 13:18:55', 'xyz', 3, 'A'),
('2019-08-18 13:20:29', 'opx', 4, 'C'),
('2019-08-20 02:06:03', 'qqqq', 9, 'A'),
('2019-08-20 03:03:27', 'YSF', 8, 'low vision'),
('2019-08-20 03:04:45', 'NR', 6, 'autis'),
('2019-08-20 03:06:49', 'FHR', 9, 'diskalkulia'),
('2019-08-20 03:08:04', 'WWN', 7, 'disgrafia'),
('2019-08-22 02:38:51', 'hilmy', 10, 'tunagrahita ringan'),
('2020-02-06 07:53:46', 'afni', 3, 'polio'),
('2020-06-30 06:25:43', 'yuyu', 3, 'tunagrahita sedang');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`ID`);

--
-- Indeks untuk tabel `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`ID`);

--
-- Indeks untuk tabel `konsultasi`
--
ALTER TABLE `konsultasi`
  ADD PRIMARY KEY (`IDk`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `akun`
--
ALTER TABLE `akun`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `gejala`
--
ALTER TABLE `gejala`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT untuk tabel `konsultasi`
--
ALTER TABLE `konsultasi`
  MODIFY `IDk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
