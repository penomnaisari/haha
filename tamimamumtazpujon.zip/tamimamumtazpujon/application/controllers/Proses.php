<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Proses extends CI_Controller {

	public function __construct() {
		parent::__construct();		
	}
	
	public function index() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->load->view('proses');
		}		
	}
	
	public function chain() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			if ($_GET['sub']=='chain') {
				$this->session->set_userdata('no', 1);
				$this->session->set_userdata('namapx', $this->input->post('nama'));
				$this->session->set_userdata('umurpx', $this->input->post('umur'));
				$this->session->set_userdata('nohp', $this->input->post('nohp'));

				$data = array(
					'a' => 1
				);
				$this->db->update('gejala', $data);
				$data = array(
					'cek' => 0
				);
				$this->db->update('konsultasi_dtl', $data);
			}
			
			redirect('proses?sub=chain');
		}
	}

	public function Y() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->session->set_userdata('no', (int)$this->session->userdata('no')+1);

			$data = array(
				'a' => 2
			);
			$this->db->where('ID', $_GET['ID']);
			$this->db->update('gejala', $data);

			$this->db->where('a', 1);			
			$sql = $this->db->get('gejala');
			if ($sql->num_rows()>0) {
				redirect('proses?sub=chain');
			} else {
				$this->db->order_by('ID', '');
				$sql = $this->db->get('gejala');
				foreach ($sql->result() as $row) {
					$data = array(
						'cek' => $row->a
					);
					$this->db->where('IDg', $row->ID);
					$this->db->update('konsultasi_dtl', $data);		
				}

				$this->db->group_by('IDkd', '');
				$sql = $this->db->get('konsultasi_dtl');
				foreach ($sql->result() as $row) {
					$this->db->where('IDkd', $row->IDkd);
					$this->db->order_by('IDg', '');
					$sqld = $this->db->get('konsultasi_dtl');
					foreach ($sqld->result() as $rowd) {
						if ((int)$rowd->cek == 0) {
							$data = array(
								'cek' => 0
							);
							$this->db->where('IDkd', $row->IDkd);
							$this->db->update('konsultasi_dtl', $data);
							
							break;
						}
					}				
				}

				$this->db->where('cek>', 0);
				$this->db->group_by('IDkd', '');					
				$sql = $this->db->get('konsultasi_dtl');
				if ($sql->num_rows()>0) {
					if ($sql->num_rows()>1) {
						$data = array(
							'cek' => 2
						);
						$this->db->where('cek', 3);
						$this->db->update('konsultasi_dtl', $data);
						
						$que = "SELECT IDkd,SUM(cek) AS total FROM konsultasi_dtl WHERE cek>0 GROUP BY IDkd ORDER BY total DESC LIMIT 0,1";
						$sql = $this->db->query($que);
						$row = $sql->row();						
					} else {
						$row = $sql->row();
					}
					
					$this->db->where('IDk', $row->IDkd);
					$sql = $this->db->get('konsultasi');
					$row = $sql->row();
					$this->session->set_userdata('diagnosa', $row->hasil);				
				} else {
					$this->session->set_userdata('diagnosa', 'Hasil Tdk Ditemukan');
				}
				
				redirect('proses?sub=result');
			}			
		}
	}
	
	public function N() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->session->set_userdata('no', (int)$this->session->userdata('no')+1);

			$data = array(
				'a' => 0
			);
			$this->db->where('ID', $_GET['ID']);
			$this->db->update('gejala', $data);

			$this->db->where('a', 1);			
			$sql = $this->db->get('gejala');
			if ($sql->num_rows()>0) {
				redirect('proses?sub=chain');
			} else {
				$this->db->order_by('ID', '');
				$sql = $this->db->get('gejala');
				foreach ($sql->result() as $row) {
					$data = array(
						'cek' => $row->a
					);
					$this->db->where('IDg', $row->ID);
					$this->db->update('konsultasi_dtl', $data);		
				}

				$this->db->group_by('IDkd', '');
				$sql = $this->db->get('konsultasi_dtl');
				foreach ($sql->result() as $row) {
					$this->db->where('IDkd', $row->IDkd);
					$this->db->order_by('IDg', '');
					$sqld = $this->db->get('konsultasi_dtl');
					foreach ($sqld->result() as $rowd) {
						if ((int)$rowd->cek == 0) {
							$data = array(
								'cek' => 0
							);
							$this->db->where('IDkd', $row->IDkd);
							$this->db->update('konsultasi_dtl', $data);
							
							break;
						}
					}				
				}

				$this->db->where('cek>', 0);
				$this->db->group_by('IDkd', '');					
				$sql = $this->db->get('konsultasi_dtl');
				if ($sql->num_rows()>0) {
					if ($sql->num_rows()>1) {
						$data = array(
							'cek' => 2
						);
						$this->db->where('cek', 3);
						$this->db->update('konsultasi_dtl', $data);
						
						$que = "SELECT IDkd,SUM(cek) AS total FROM konsultasi_dtl WHERE cek>0 GROUP BY IDkd ORDER BY total DESC LIMIT 0,1";
						$sql = $this->db->query($que);
						$row = $sql->row();						
					} else {
						$row = $sql->row();
					}
					
					$this->db->where('IDk', $row->IDkd);
					$sql = $this->db->get('konsultasi');
					$row = $sql->row();
					$this->session->set_userdata('diagnosa', $row->hasil);				
				} else {
					$this->session->set_userdata('diagnosa', 'Hasil Tdk Ditemukan');
				}
				
				redirect('proses?sub=result');
			}			
		}
	}
	
	public function A() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->session->set_userdata('no', (int)$this->session->userdata('no')+1);

			$data = array(
				'a' => 3
			);
			$this->db->where('ID', $_GET['ID']);
			$this->db->update('gejala', $data);

			$this->db->where('a', 1);			
			$sql = $this->db->get('gejala');
			if ($sql->num_rows()>0) {
				redirect('proses?sub=chain');
			} else {
				$this->db->order_by('ID', '');
				$sql = $this->db->get('gejala');
				foreach ($sql->result() as $row) {
					$data = array(
						'cek' => $row->a
					);
					$this->db->where('IDg', $row->ID);
					$this->db->update('konsultasi_dtl', $data);		
				}

				$this->db->group_by('IDkd', '');
				$sql = $this->db->get('konsultasi_dtl');
				foreach ($sql->result() as $row) {
					$this->db->where('IDkd', $row->IDkd);
					$this->db->order_by('IDg', '');
					$sqld = $this->db->get('konsultasi_dtl');
					foreach ($sqld->result() as $rowd) {
						if ((int)$rowd->cek == 0) {
							$data = array(
								'cek' => 0
							);
							$this->db->where('IDkd', $row->IDkd);
							$this->db->update('konsultasi_dtl', $data);
							
							break;
						}
					}				
				}

				$this->db->where('cek>', 0);
				$this->db->group_by('IDkd', '');					
				$sql = $this->db->get('konsultasi_dtl');
				if ($sql->num_rows()>0) {
					if ($sql->num_rows()>1) {
						$data = array(
							'cek' => 2
						);
						$this->db->where('cek', 3);
						$this->db->update('konsultasi_dtl', $data);
						
						$que = "SELECT IDkd,SUM(cek) AS total FROM konsultasi_dtl WHERE cek>0 GROUP BY IDkd ORDER BY total DESC LIMIT 0,1";
						$sql = $this->db->query($que);
						$row = $sql->row();						
					} else {
						$row = $sql->row();
					}
					
					$this->db->where('IDk', $row->IDkd);
					$sql = $this->db->get('konsultasi');
					$row = $sql->row();
					$this->session->set_userdata('diagnosa', $row->hasil);				
				} else {
					$this->session->set_userdata('diagnosa', 'Hasil Tdk Ditemukan');
				}
				
				redirect('proses?sub=result');
			}			
		}
	}
	
	public function simpan() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$data = array(
				'nama' => $this->session->userdata('namapx'),
				'umur' => $this->session->userdata('umurpx'),
				'diagnosa' => $this->session->userdata('diagnosa')
				
			);
			$this->db->insert('log', $data);

			redirect('proses');
		}		
	}
	
}
?>