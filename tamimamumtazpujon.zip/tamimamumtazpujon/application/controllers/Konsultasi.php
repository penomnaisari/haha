<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Konsultasi extends CI_Controller {

	public function __construct() {
		parent::__construct();		
	}
	
	public function index() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->load->view('konsultasi');
		}		
	}
	
	public function tambah() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$sql = $this->db->get_where('konsultasi', array('hasil' => $this->input->post('hasil')));
			if ($sql->num_rows()<1) {			
				$data = array(
					'hasil' => $this->input->post('hasil')
				);
				$this->db->insert('konsultasi', $data);

				$this->db->order_by('IDk', 'DESC');
				$sql = $this->db->get('konsultasi', 0, 1);
				$row = $sql->row();

				$this->db->order_by('ID', '');
				$sqlg = $this->db->get('gejala');
				foreach ($sqlg->result() as $rowg) {
					if(!empty($this->input->post('G' . $rowg->ID . ''))) {
						$data = array(
							'IDkd' => $row->IDk,
							'IDg' => $rowg->ID,
						);
						$this->db->insert('konsultasi_dtl', $data);
					}				
				}								
			}
			
			redirect('konsultasi');
		}		
	}
	
	public function edit() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$sql = $this->db->get_where('konsultasi', array('hasil' => $this->input->post('hasil'),'IDk!=' => $_GET['ID']));
			if ($sql->num_rows()<1) {			
				$data = array(
					'hasil' => $this->input->post('hasil')
				);
				$this->db->where('IDk', $_GET['ID']);
				$this->db->update('konsultasi', $data);

				$this->db->delete('konsultasi_dtl', array('IDkd' => $_GET['ID']));
				$this->db->order_by('ID', '');
				$sqlg = $this->db->get('gejala');
				foreach ($sqlg->result() as $rowg) {
					if(!empty($this->input->post('G' . $rowg->ID . ''))) {
						$data = array(
							'IDkd' => $_GET['ID'],
							'IDg' => $rowg->ID,
						);
						$this->db->insert('konsultasi_dtl', $data);
					}				
				}
			}
			
			redirect('konsultasi');
		}
	}
	
	public function delete() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->db->delete('konsultasi', array('IDk' => $_GET['ID']));
			$this->db->delete('konsultasi_dtl', array('IDkd' => $_GET['ID']));

			redirect('konsultasi');
		}		
	}
	
}
?>