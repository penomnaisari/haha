<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {

	public function __construct() {
		parent::__construct();		
	}
	
	public function index() {
		if (empty($this->session->userdata('user')) || ($this->session->userdata('user')!='Super Admin' && $this->session->userdata('user')!='Admin')) {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->load->view('report');
		}		
	}
	
	public function filter1() {
		if (empty($this->session->userdata('user')) || ($this->session->userdata('user')!='Super Admin' && $this->session->userdata('user')!='Admin')) {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$tgly = $this->session->set_userdata('tgly', substr($this->input->post('tgl'),4,4));
			$tglm = $this->session->set_userdata('tglm', substr($this->input->post('tgl'),2,2));
			$tgld = $this->session->set_userdata('tgld', substr($this->input->post('tgl'),0,2));
			
			redirect('reporttanggal');
		}		
	}
	
	public function filter2() {
		if (empty($this->session->userdata('user')) || ($this->session->userdata('user')!='Super Admin' && $this->session->userdata('user')!='Admin')) {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->session->set_userdata('bln', $this->input->post('bln'));
			$this->session->set_userdata('thn', $this->input->post('thn'));
			
			redirect('reportbulan');
		}		
	}
	
	public function cetak() {
		if (empty($this->session->userdata('user')) || ($this->session->userdata('user')!='Super Admin' && $this->session->userdata('user')!='Admin')) {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			if ($_GET['filter']=='all') {
				redirect('dokumen?report=all');
			}
			else if ($_GET['filter']=='hari') {
				redirect('dokumen?report=hari');
			}			
			else if ($_GET['filter']=='bulan') {
				redirect('dokumen?report=bulan');
			}			
		}		
	}
	
}
?>