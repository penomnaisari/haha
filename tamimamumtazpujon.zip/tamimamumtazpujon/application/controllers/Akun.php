<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Akun extends CI_Controller {

	public function __construct() {
		parent::__construct();		
	}
	
	public function index() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->load->view('akun');
		}		
	}
	
	public function tambah() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$sql = $this->db->get_where('akun', array('user' => $this->input->post('user')));
			if ($sql->num_rows()<1) {			
				$data = array(
					'nama' => $this->input->post('nama'),
					'user' => $this->input->post('user'),
					'pass' => MD5($this->input->post('pass')),
					'type' => $this->input->post('type')
				);
				$this->db->insert('akun', $data);
			}
	
			redirect('akun');
		}		
	}
	
	public function edit() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$sql = $this->db->get_where('akun', array('user' => $this->input->post('user'),'ID!=' => $_GET['ID']));
			if ($sql->num_rows()<1) {
				$data = array(
					'user' => $this->input->post('user'),
					'pass' => MD5($this->input->post('pass')),
					'type' => $this->input->post('type')
				);
				$this->db->where('ID', $_GET['ID']);
				$this->db->update('akun', $data);
			}
		
			redirect('akun');
		}		
	}
	
	public function delete() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->db->delete('akun', array('ID' => $_GET['ID']));

			redirect('akun');
		}		
	}
	
}
?>