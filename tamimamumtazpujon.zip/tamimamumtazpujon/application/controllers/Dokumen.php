<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dokumen extends CI_Controller {

	public function __construct() {
		parent::__construct();
		require_once(APPPATH.'third_party/pdf/fpdf.php');
	}
	
	public function index() {
		if (empty($this->session->userdata('user')) || ($this->session->userdata('user')!='Super Admin' && $this->session->userdata('user')!='Admin')) {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$pdf = new FPDF('P', 'cm', 'A4');
			$pdf->AddPage();	
			$pdf->Image('asset/images/icon.png',1.5,1.75,1.5);
			
			$pdf->SetXY(1,1.5);
			$pdf->SetFont('arial','B',12); $pdf->Cell(19,0.75,"DETEKSI KEBUTUHAN ANAK",'',1,'C',0);
			$pdf->SetFont('arial','B',12); $pdf->Cell(19,0.75,"SLB MUMTAZ PUJON KOTA MALANG",'',1,'C',0);
			$pdf->SetFont('arial','B',12); $pdf->Cell(19,0.75,"Medical Record",'',1,'C',0);
			$pdf->Cell(19,0.25,"",'B',0,'',0);
	
			$pdf->SetXY(1,4.75);
			$pdf->SetFont('arial','B',10);
			$pdf->Cell(4,0.75,"Tgl / Jam",'LRTB',0,'C',0);
			$pdf->Cell(7,0.75,"Nama Pasien",'LRTB',0,'C',0);
			$pdf->Cell(3,0.75,"Umur (Th)",'LRTB',0,'C',0);
			$pdf->Cell(5,0.75,"Diagnosa",'LRTB',1,'C',0);

			$pdf->SetFont('arial','',10);
			if ($_GET['report']=='all') {
				$que = "SELECT * FROM log ORDER BY time DESC";
               }
			else if ($_GET['report']=='hari') {
				$que = "SELECT * FROM log WHERE DAY(time)=" . $this->session->userdata('tgld') . " AND MONTH(time)=" . $this->session->userdata('tglm') . " AND YEAR(time)=" . $this->session->userdata('tgly') . " ORDER BY time DESC";
               }
			else if ($_GET['report']=='bulan') {
				$que = "SELECT * FROM log WHERE MONTH(time)=" . $this->session->userdata('bln') . " AND YEAR(time)=" . $this->session->userdata('thn') . " ORDER BY time DESC";
               }
			$sql = $this->db->query($que);
			foreach ($sql->result() as $row) {
				$pdf->Cell(4,1,date_format(date_create($row->time),'d-m-Y / H:i'),'LRB',0,'C',0);
				$pdf->Cell(7,1,' '.$row->nama,'LRB',0,'',0);
				$pdf->Cell(3,1,$row->umur,'LRB',0,'C',0);
				$pdf->Cell(5,1,$row->diagnosa,'LRB',1,'C',0);
			}
			$pdf->Output();
		}
	}
	
}
?>