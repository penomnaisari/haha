<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gejala extends CI_Controller {

	public function __construct() {
		parent::__construct();		
	}
	
	public function index() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->load->view('gejala');
		}		
	}
	
	public function tambah() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$sql = $this->db->get_where('gejala', array('nama' => $this->input->post('nama')));
			if ($sql->num_rows()<1) {			
				$data = array(
					'nama' => $this->input->post('nama'),
					'pengertian' => $this->input->post('pengertian')
				);
				$this->db->insert('gejala', $data);
			}
			
			redirect('gejala');
		}		
	}
	
	public function edit() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$sql = $this->db->get_where('gejala', array('nama' => $this->input->post('nama'),'ID!=' => $_GET['ID']));
			if ($sql->num_rows()<1) {			
				$data = array(
					'nama' => $this->input->post('nama'),
					'pengertian' => $this->input->post('pengertian')
				);
				$this->db->where('ID', $_GET['ID']);
				$this->db->update('gejala', $data);
			}
			
			redirect('gejala');
		}		
	}
	
	public function delete() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->db->delete('gejala', array('ID' => $_GET['ID']));

			redirect('gejala');
		}		
	}
	
}
?>