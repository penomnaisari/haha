<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct() {
		parent::__construct();
	}
	
	public function index() {
		$this->load->view('login');
	}

	public function in() {
		$sql = $this->db->get_where('akun', array('user' => $this->input->post('user'),'pass' => MD5($this->input->post('pass'))));
		if ($sql->num_rows()>0) {
			$row = $sql->row();
			if ($row->type=='1') {
				$this->session->set_userdata('user', 'Admin');
				$this->session->set_userdata('nama', $row->nama);
				redirect('proses');
			}
			if ($row->type=='2') {
				$this->session->set_userdata('user', 'Super Admin');
				$this->session->set_userdata('nama', $row->nama);
				redirect('akun');
			}			
		} else {
			if ($this->input->post('user')=='admin' && $this->input->post('pass')=='admin') {
				$this->session->set_userdata('user', 'Super Admin');
				$this->session->set_userdata('nama', 'Admin');
				redirect('akun');
			} else {
				$this->session->set_userdata('user', '');
				echo "<script>alert('Cek Username Dan Password');window.history.back();</script>";
			}
		}
	}

	public function out() {
		$this->session->sess_destroy();
		redirect('login');
	}
}
?>