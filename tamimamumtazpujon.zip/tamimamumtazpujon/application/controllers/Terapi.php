<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Terapi extends CI_Controller {

	public function __construct() {
		parent::__construct();		
	}
	
	public function index() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->load->view('Terapi');
		}		
	}
	
	public function tambah() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->db->where('IDkd', $this->input->post('IDkd'));
			$this->db->or_where('nama', $this->input->post('nama'));
			$sql = $this->db->get('terapi');
			if ($sql->num_rows()<1) {			
				$data = array(
					'IDkd' => $this->input->post('IDkd'),
					'nama' => $this->input->post('nama')
				);
				$this->db->insert('terapi', $data);
			}
			
			redirect('terapi');
		}		
	}
	
	public function edit() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$que = "IDt!='" . $_GET['ID'] . "' AND IDkd='" . $this->input->post('IDkd') . "' OR nama='" . $this->input->post('nama') . "'";
			$this->db->where($que);
			$sql = $this->db->get('terapi');
			if ($sql->num_rows()<1) {			
				$data = array(
					'IDkd' => $this->input->post('IDkd'),
					'nama' => $this->input->post('nama')
				);
				$this->db->where('IDt', $_GET['ID']);
				$this->db->update('terapi', $data);
			}
			
			redirect('terapi');
		}
	}
	
	public function detail() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$sql = $this->db->get_where('terapi_dtl', array('tindakan' => $this->input->post('tindakan')));
			if ($sql->num_rows()<1) {			
				$data = array(
					'IDtd' => $_GET['ID'],
					'tindakan' => $this->input->post('tindakan')
				);
				$this->db->insert('terapi_dtl', $data);
			}
			
			redirect('terapi');
		}
	}
	
	public function delete() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->db->delete('terapi', array('IDt' => $_GET['ID']));
			$this->db->delete('terapi_dtl', array('IDtd' => $_GET['ID']));
			
			redirect('terapi');
		}		
	}
	
	public function deletedtl() {
		if (empty($this->session->userdata('user')) || $this->session->userdata('user')!='Super Admin') {
			$this->session->sess_destroy();
			redirect('login');
		}
		else {
			$this->db->delete('terapi_dtl', array('IDtdt' => $_GET['ID']));
			
			redirect('terapi');
		}		
	}
	
}
?>