<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!doctype html>
<head>
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <title>Report - SLB Mumtaz Pujon</title>
     <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
     <link rel="shortcut icon" href="asset/images/icon.png" type="image/png">
     <link rel="stylesheet" href="asset/css/font-awesome.min.css">
     <link rel="stylesheet" href="asset/css/material-design-iconic-font.min.css">
     <link rel="stylesheet" href="asset/css/bootstrap.min.css">
     <link rel="stylesheet" href="asset/css/animsition.min.css">
     <link rel="stylesheet" href="asset/css/bootstrap-progressbar-3.3.4.min.css">
     <link rel="stylesheet" href="asset/css/animate.css">
     <link rel="stylesheet" href="asset/css/hamburgers.min.css">
     <link rel="stylesheet" href="asset/css/slick.css">
     <link rel="stylesheet" href="asset/css/select2.min.css">
     <link rel="stylesheet" href="asset/css/perfect-scrollbar.css">
     <link rel="stylesheet" href="asset/css/theme.css">    
     <link rel="stylesheet" href="asset/css/style.css">
     <link rel="stylesheet" href="asset/css/datepicker.css">
     <script>
        function filter() {
            if (+document.getElementById('filter').value == 1) {
                document.getElementById('1').style.display = 'block';
                document.getElementById('2').style.display = 'none';
            } else if (+document.getElementById('filter').value == 2) {
                document.getElementById('1').style.display = 'none';
                document.getElementById('2').style.display = 'block';
            }
        }
        function submit1(e) {
            document.getElementById('val').value = document.getElementById('tgl').value.split('-')[2] + document.getElementById('tgl').value.split('-')[1] + document.getElementById('tgl').value.split('-')[0];
            e.form.submit();
        }
        function submit2(e) {
            if (+document.getElementById('bln').value > 0 && +document.getElementById('thn').value > 0) {
                e.form.submit();
            }            
        }
     </script>
</head>
<body>
     <div class="page-wrapper">
          <aside class="menu-sidebar d-none d-lg-block">
               <div class="menu-sidebar__content js-scrollbar1">
                    <nav class="navbar-sidebar">
                         <ul class="list-unstyled navbar__list">
                              <?php if ($this->session->userdata('user')=='Super Admin') { ?>
                              <li><a href="<?php echo site_url('akun') ?>">
                                   <i class="fa fa-user"></i>Akun
                              </a></li>
                              <li><a href="<?php echo site_url('gejala') ?>">
                                   <i class="fa fa-question-circle"></i>Gejala
                              </a></li>
                              <li><a href="<?php echo site_url('konsultasi') ?>">
                                   <i class="fa fa-sort-amount-asc"></i>Konsultasi
                              </a></li>
                              <?php } else if ($this->session->userdata('user')=='Admin') { ?>
                              <li><a href="<?php echo site_url('proses') ?>">
                                   <i class="fa fa-stethoscope"></i>Proses
                              </a></li>                            
                              <?php } ?>
                              <li><a href="<?php echo site_url('report') ?>">
                                   <i class="fa fa-file-pdf-o active"></i><i class="active">Report</i>
                              </a></li>                            
                         </ul>
                    </nav>
               </div>
          </aside>

          <div class="page-container">
                <header class="header-desktop">
                    <div class="section__content section__content--p30">
                        <div class="container-fluid">
                            <div class="header-wrap">
                                <div class="header-button">
                                    <div class="account-wrap">
                                        <div class="account-item clearfix js-item-menu">
                                            <div class="image"></div>                                        
                                            <div class="content">
                                                <?php echo $this->session->userdata('nama') ?> - <a href="<?php echo site_url('login/out') ?>">Logout</a>
                                            </div>                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>

                <div class="main-content">
                    <div class="section__content section__content--p30">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h2 class="title-1 m-b-16">Report</h2>
                                    <br />
                                    <div class="col col-md-3" style="margin-bottom: 0.5em; padding-left: 0; float: left;">
                                        <select onchange="filter()" id="filter" class="form-control">
                                            <option value="">Filter</option>
                                            <option value="1">Per Hari</option>
                                            <option value="2" selected>Per Bulan</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col col-md-3" style="margin-bottom: 0.5em; padding-right: 0; float: right;">
                                        <div id="1" class="col col-md-10" style="padding: 0; display: none; float: right;">
                                            <form method="post" action="report/filter1">
                                                <input hidden id="val" name="tgl">
                                                <div class="input-append date form_date">
                                                    <input type="date" onchange="submit1(this)" id="tgl" class="form-control" style="background: white; float: left; width: 90%;">
                                                    <span class="add-on" style="float: right; width: 10%;"><i class="fa fa-calendar"></i></span>
                                                </div>                                                
                                            </form>
                                        </div>
                                        <div id="2" class="col col-md-12" style="padding: 0;">
                                            <form method="post" action="report/filter2">
                                                <div class="col col-md-6" style="padding: 0; float: left;">
                                                    <select onchange="submit2(this)" id="bln" name="bln" class="form-control" required>
                                                        <option value="" selected>Bulan</option>
                                                        <?php for ($y=1; $y<=12; $y++) { if ($y<10) { $bln = '0'.$y; } else { $bln = $y; } if ($y==(int)$this->session->userdata('bln')) { $sel = 'selected'; } else { $sel = ''; } ?>
                                                            <option value="<?php echo $y ?>" <?php echo $sel ?>><?php echo $bln ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                                <div class="col col-md-5" style="padding: 0; float: right;">
                                                    <select onchange="submit2(this)" id="thn" name="thn" class="form-control" required>
                                                        <option value="" selected>Tahun</option>
                                                        <?php for ($y=date('Y'); $y>date('Y')-2; $y--) { if ($y==(int)$this->session->userdata('thn')) { $sel = 'selected'; } else { $sel = ''; } ?>
                                                            <option value="<?php echo $y ?>" <?php echo $sel ?>><?php echo $y ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    
                                    <div class="table-responsive table--no-card m-b-40">
                                        <table class="table table-borderless table-striped table-earning">
                                            <thead>
                                                <tr>
                                                    <th>Tgl / Jam</th>
                                                    <th>Nama Pasien</th>
                                                    <th>Umur (th)</th>
                                                    <th>Diagnosa</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                  <?php
                                                       $y = 0;
                                                       $que = "SELECT * FROM log WHERE MONTH(time)=" . $this->session->userdata('bln') . " AND YEAR(time)=" . $this->session->userdata('thn') . " ORDER BY time DESC";
                                                       $sql = $this->db->query($que);                                                       
                                                       foreach ($sql->result() as $row) {
                                                  ?>
                                                  <tr>
                                                       <td align="center"><?php echo date_format(date_create($row->time),'d-m-Y / H:i') ?></td>
                                                       <td><?php echo $row->nama ?></td>
                                                       <td><?php echo $row->umur ?></td>
                                                       <td><?php echo $row->diagnosa ?></td>
                                                  </tr>
                                                  <?php $y++; } ?>
                                            </tbody>                                            
                                        </table>
                                    </div>
                                    <?php if ($y>0) { ?>
                                    <a href="<?php echo site_url('report/cetak') ?>?filter=bulan" target="_blank" class="role user">Cetak</a>
                                    <?php } ?>
                                </div>                            
                            </div>                            
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="copyright">
                                        <p>Skripsi JTI Polinema - Copyright &copy; 2019 1541180163 Hilmy</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                
            </div>
          </div>
                

     </div>
     <script src="asset/js/jquery-3.2.1.min.js"></script>
     <script src="asset/js/bootstrap-datepicker.js"></script>
     <script type="text/javascript">
        $(".form_date").datepicker({
            format: "dd-mm-yyyy",
            autoclose: true,
            todayBtn: false,
            pickerPosition: "bottom-left"
        });
    </script>
</body>
</html>