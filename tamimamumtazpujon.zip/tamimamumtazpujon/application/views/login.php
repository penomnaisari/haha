<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!doctype html>
<head>
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <title>Deteksi Kebutuhan Anak</title>
     <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
     <link rel="shortcut icon" href="asset/images/icon.png" type="image/png">
     <link rel="stylesheet" href="asset/css/style.css">
</head>
<body>
     <div class="bg_body"></div>        
     <label class="subheader">Deteksi Kebutuhan Anak</label>        
     <div class="cardlogin">
          <form method="post" action="login/in">
               <h2 class="login">Admin</h2>
               <input type="text" name="user" maxlength="10" placeholder="Username" required />
               <input type="password" name="pass" maxlength="10" placeholder="Password" required />
               <input type="submit" value="Login" />
          </form>
     </div>        
     <p>Skripsi JTI Polinema - Copyright &copy; 2019 1541180163 Hilmy</p>
</body>
</html>