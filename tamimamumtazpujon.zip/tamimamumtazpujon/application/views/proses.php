<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!doctype html>
<head>
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <title>Proses - SLB Mumtaz Pujon</title>
     <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
     <link rel="shortcut icon" href="asset/images/icon.png" type="image/png">
     <link rel="stylesheet" href="asset/css/font-awesome.min.css">
     <link rel="stylesheet" href="asset/css/material-design-iconic-font.min.css">
     <link rel="stylesheet" href="asset/css/bootstrap.min.css">
     <link rel="stylesheet" href="asset/css/animsition.min.css">
     <link rel="stylesheet" href="asset/css/bootstrap-progressbar-3.3.4.min.css">
     <link rel="stylesheet" href="asset/css/animate.css">
     <link rel="stylesheet" href="asset/css/hamburgers.min.css">
     <link rel="stylesheet" href="asset/css/slick.css">
     <link rel="stylesheet" href="asset/css/select2.min.css">
     <link rel="stylesheet" href="asset/css/perfect-scrollbar.css">
     <link rel="stylesheet" href="asset/css/theme.css">    
     <link rel="stylesheet" href="asset/css/style.css">
</head>
<body>
     <div class="page-wrapper">
          <aside class="menu-sidebar d-none d-lg-block">
               <div class="menu-sidebar__content js-scrollbar1">
                    <nav class="navbar-sidebar">
                         <ul class="list-unstyled navbar__list">                            
                              <li><a href="<?php echo site_url('proses') ?>">
                                   <i class="fa fa-stethoscope active"></i><i class="active">Proses</i>
                              </a></li>                            
                              <li><a href="<?php echo site_url('report') ?>">
                                   <i class="fa fa-file-pdf-o"></i>Report
                              </a></li>                            
                         </ul>
                    </nav>
               </div>
          </aside>

          <div class="page-container">
                <header class="header-desktop">
                    <div class="section__content section__content--p30">
                        <div class="container-fluid">
                            <div class="header-wrap">
                                <div class="header-button">
                                    <div class="account-wrap">
                                        <div class="account-item clearfix js-item-menu">
                                            <div class="image"></div>                                        
                                            <div class="content">
                                                <?php echo $this->session->userdata('nama') ?> - <a href="<?php echo site_url('login/out') ?>">Logout</a>
                                            </div>                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>

                <div class="main-content">
                    <div class="section__content section__content--p30">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h2 class="title-1 m-b-16">Proses</h2>
                                    <br />
                                        <div class="card">
                                             <?php if (!isset($_GET['sub'])) { ?>
                                             <form method="post" action="proses/chain?sub=chain">
                                             <div class="card-body card-block">
                                             <div class="row form-group">
                                                  <div class="col col-md-12">
                                                       <i>Jawablah pertanyaan - pertanyaan berikut ini</i>
                                                  </div>
                                             </div>
                                             </div>
                                             <div class="card-body card-block">
                                             <div class="row form-group">
                                                  <div class="col col-md-2">
                                                       <label for="text-input" class="form-control-label">Nama</label>
                                                  </div>
                                                  <div class="col-12 col-md-4">
                                                       <input type="text" name="nama" maxLength="30" class="form-control" required />
                                                  </div>
                                             </div>
                                             </div>
                                             
                                             <div class="card-body card-block">
                                             <div class="row form-group">
                                                  <div class="col col-md-2">
                                                       <label for="text-input" class="form-control-label">Umur (th)</label>
                                                  </div>
                                                  <div class="col-12 col-md-4">
                                                       <select name="umur" class="form-control" required>
                                                            <option value="" selected></option>
                                                            <?php for ($y=1; $y<=15; $y++) { ?>
                                                            <option value="<?php echo $y ?>"><?php echo $y ?></option>
                                                            <?php } ?>
                                                       </select>
                                                  </div>
                                             </div>
                                             </div>

                                             <div class="card-body card-block">
                                             <div class="row form-group">
                                                  <div class="col col-md-2">
                                                       <label for="text-input" class="form-control-label">No hp orang tua</label>
                                                  </div>
                                                  <div class="col-12 col-md-4">
                                                       <input type="text" name="nohp" maxLength="15" class="form-control"  required />
                                                  </div>                                          
                                             </div>
                                             <font size="2" color=#dcdcdc>angka 0 di awal nomor diganti dengan 62</font>
                                             </div>
                                             <div class="card-body card-block"><div class="row form-group"></div></div>
                                             <div class="row form-group">
                                                  <div class="col col-md-2"></div>                                                  
                                                  <div class="col col-md-4">
                                                       <button type="submit" class="role user">Mulai</button>
                                                  </div>
                                             </div>                                             
                                             </form>
                                             <?php } else if ($_GET['sub']=='chain') { ?>
                                                  <?php
                                                       $this->db->where('a', 1);
                                                       $this->db->order_by('ID', '');
                                                       $sql = $this->db->get('gejala', 0, 1);
                                                       $row = $sql->row();                                                       
                                                  ?>
                                                  <div class="card-body card-block">
                                                       <div class="row form-group">
                                                            <div class="col col-md-6">
                                                                 <i>Gejala yang terjadi pada kondisi anak</i>
                                                            </div>
                                                            <div class="col col-md-4" style="text-align: right;">
                                                                 Nama : <?php echo $this->session->userdata('namapx') ?>
                                                            </div>
                                                            <div class="col col-md-2" style="text-align: right;">
                                                                 Umur (th) : <?php echo $this->session->userdata('umurpx') ?>
                                                            </div>
                                                       </div>
                                                  </div>
                                                  <div class="row form-group">
                                                       <div class="col col-md-12">
                                                            <?php echo $this->session->userdata('no') ?>. )&nbsp;&nbsp;<?php echo $row->pengertian ?>
                                                       </div>
                                                  </div>
                                                  <div class="card-body card-block"><div class="row form-group"></div></div>
                                                  <div class="card-body card-block"><div class="row form-group"></div></div>
                                                  <div class="row form-group">
                                                       <div class="col col-md-12">
                                                            <a href="<?php echo site_url('proses/Y') ?>?ID=<?php echo $row->ID ?>" class="role member">Ya</a>
                                                            &nbsp;&nbsp;&nbsp;
                                                            <a href="<?php echo site_url('proses/N') ?>?ID=<?php echo $row->ID ?>" class="role admin">Tidak</a>
                                                            &nbsp;&nbsp;&nbsp;
                                                            <a href="<?php echo site_url('proses/A') ?>?ID=<?php echo $row->ID ?>" class="role user">Tidak Tau</a>
                                                       </div>
                                                  </div>
                                             <?php } else if ($_GET['sub']=='result') { ?>
                                             <div class="card-body card-block">
                                             <div class="row form-group">
                                                  <div class="col col-md-6">
                                                       <i>Diagnosa kebutuhan anak</i>
                                                  </div>
                                             </div>
                                             </div>
                                             <div class="card-body card-block">
                                             <div class="row form-group">
                                                  <div class="col col-md-2">
                                                       <label for="text-input" class="form-control-label">Nama</label>
                                                  </div>
                                                  <div class="col-12 col-md-4">
                                                       : <?php echo $this->session->userdata('namapx') ?>
                                                  </div>
                                             </div>
                                             </div>
                                             <div class="card-body card-block">
                                             <div class="row form-group">
                                                  <div class="col col-md-2">
                                                       <label for="text-input" class="form-control-label">Umur (th)</label>
                                                  </div>
                                                  <div class="col-12 col-md-4">
                                                       : <?php echo $this->session->userdata('umurpx') ?>
                                                  </div>
                                             </div>
                                             </div>
                                             <div class="card-body card-block">
                                             <div class="row form-group">
                                                  <div class="col col-md-2">
                                                       <label for="text-input" class="form-control-label">Hasil</label>
                                                  </div>
                                                  <div class="col-12 col-md-4">
                                                       : <?php echo $this->session->userdata('diagnosa') ?>
                                                  </div>
                                             </div>
                                             </div>
                                             
                                             <!--edit tambah whatsapp-->
                                             <div class="card-body card-block">
                                             <div class="row form-group">
                                                  <div class="col col-md-3">
                                                       <label for="text-input" class="form-control-label">Kirim hasil ke orangtua</label>
                                                  </div>
                                                  <div class="col-12 col-md-3">
                                                       <a href="https://wa.me/<?php echo $this->session->userdata('nohp') ?>?text=Hasil%20diagnosa%20atas%20nama%20<?php echo $this->session->userdata('namapx') ?>%20menurut%20sistem%20adalah%20<?php echo $this->session->userdata('diagnosa') ?>%0A%0A---SLB%20Tamima%20Mumtaz--- " target="_blank" class="role view">Kirim Pesan</a>
                                                  </div>
                                             </div>
                                             </div>

                                             <div class="card-body card-block"><div class="row form-group"></div></div>
                                             <div class="row form-group">
                                                  <div class="col col-md-2"></div>                                                  
                                                  <div class="col col-md-4">
                                                       <?php if ($this->session->userdata('diagnosa')!='Hasil Tdk Ditemukan') { ?>
                                                       <a href="<?php echo site_url('proses/simpan') ?>" class="role member">Simpan</a>
                                                       &nbsp;&nbsp;&nbsp;
                                                       <?php } ?>
                                                       <a href="<?php echo site_url('proses') ?>" class="role user">Ulangi</a>
                                                  </div>
                                             </div>                                             
                                             <?php } ?>
                                        </div>
                                </div>                            
                            </div>                            
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="copyright">
                                        <p>Skripsi JTI Polinema - Copyright &copy; 2019 1541180163 Hilmy</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                
            </div>
          </div>
                

     </div>
</body>
</html>