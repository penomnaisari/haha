<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!doctype html>
<head>
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <title>Gejala - SLB Mumtaz Pujon</title>
     <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
     <link rel="shortcut icon" href="asset/images/icon.png" type="image/png">
     <link rel="stylesheet" href="asset/css/font-awesome.min.css">
     <link rel="stylesheet" href="asset/css/material-design-iconic-font.min.css">
     <link rel="stylesheet" href="asset/css/bootstrap.min.css">
     <link rel="stylesheet" href="asset/css/animsition.min.css">
     <link rel="stylesheet" href="asset/css/bootstrap-progressbar-3.3.4.min.css">
     <link rel="stylesheet" href="asset/css/animate.css">
     <link rel="stylesheet" href="asset/css/hamburgers.min.css">
     <link rel="stylesheet" href="asset/css/slick.css">
     <link rel="stylesheet" href="asset/css/select2.min.css">
     <link rel="stylesheet" href="asset/css/perfect-scrollbar.css">
     <link rel="stylesheet" href="asset/css/theme.css">    
     <link rel="stylesheet" href="asset/css/style.css">
</head>
<body>
     <div class="page-wrapper">
          <aside class="menu-sidebar d-none d-lg-block">
               <div class="menu-sidebar__content js-scrollbar1">
                    <nav class="navbar-sidebar">
                         <ul class="list-unstyled navbar__list">                            
                              <li><a href="<?php echo site_url('akun') ?>">
                                   <i class="fa fa-user"></i>Akun
                              </a></li>
                              <li><a href="<?php echo site_url('gejala') ?>">
                                   <i class="fa fa-question-circle active"></i><i class="active">Gejala</i>
                              </a></li>
                              <li><a href="<?php echo site_url('konsultasi') ?>">
                                   <i class="fa fa-sort-amount-asc"></i>Konsultasi
                              </a></li>
                              <li><a href="<?php echo site_url('report') ?>">
                                   <i class="fa fa-file-pdf-o"></i>Report
                              </a></li>                            
                         </ul>
                    </nav>
               </div>
          </aside>

          <div class="page-container">
                <header class="header-desktop">
                    <div class="section__content section__content--p30">
                        <div class="container-fluid">
                            <div class="header-wrap">
                                <div class="header-button">
                                    <div class="account-wrap">
                                        <div class="account-item clearfix js-item-menu">
                                            <div class="image"></div>                                        
                                            <div class="content">
                                                <?php echo $this->session->userdata('nama') ?> - <a href="<?php echo site_url('login/out') ?>">Logout</a>
                                            </div>                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>

                <div class="main-content">
                    <div class="section__content section__content--p30">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h2 class="title-1 m-b-16">Gejala</h2>
                                    <br />
                                    <?php if (!isset($_GET['p'])) { ?>
                                    <div class="table-responsive table--no-card m-b-40">
                                        <table class="table table-borderless table-striped table-earning">
                                            <thead>
                                                <tr>
                                                    <th>Nama</th>
                                                    <th>Pengertian</th>
                                                    <th width="10%" class="text-center">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                  <?php
                                                       $this->db->order_by('nama', '');
                                                       $sql = $this->db->get('gejala');
                                                       foreach ($sql->result() as $row) {
                                                  ?>
                                                  <tr>
                                                       <td><?php echo $row->nama ?></td>
                                                       <td><?php echo $row->pengertian ?></td>
                                                       <td class="text-center">
                                                            <button onClick="window.location.href='?p=edit&ID=<?php echo $row->ID ?>';" class="role member">Edit</button>
                                                            &nbsp;&nbsp;&nbsp;
                                                            <button onClick="window.location.href='<?php echo site_url('gejala/delete') ?>?ID=<?php echo $row->ID ?>';" class="role admin">Hapus</button>
                                                       </td>
                                                  </tr>
                                                  <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <button onClick="window.location.href='?p=tambah';" class="role user">Tambah</button>
                                   <?php } else { ?>
                                        <div class="card">
                                             <?php if ($_GET['p']=='tambah') {
                                                  $nama = 'G'; $pengertian = '';
                                             ?>
                                             <?php } else if ($_GET['p']=='edit') {
                                                  $sql = $this->db->get_where('gejala', array('ID' => $_GET['ID']));
                                                  $row = $sql->row();
                                                  
                                                  $nama = $row->nama; $pengertian = $row->pengertian; 
                                             ?>
                                             <?php } ?>
                                             <?php if ($_GET['p']=='tambah') { ?>
                                                  <form method="post" action="gejala/tambah">
                                             <?php } else if ($_GET['p']=='edit') { ?>
                                                  <form method="post" action="gejala/edit?ID=<?php echo $_GET['ID'] ?>">
                                             <?php } ?>
                                             <div class="card-body card-block">
                                             <div class="row form-group">
                                                  <div class="col col-md-2">
                                                       <label for="text-input" class="form-control-label">Nama</label>
                                                  </div>
                                                  <div class="col-12 col-md-4">
                                                       <input type="text" name="nama" value="<?php echo $nama ?>" maxLength="3" class="form-control" required />
                                                  </div>
                                             </div>
                                             </div>
                                             <div class="card-body card-block">
                                             <div class="row form-group">
                                                  <div class="col col-md-2">
                                                       <label for="text-input" class="form-control-label">Pengertian</label>
                                                  </div>
                                                  <div class="col-12 col-md-4">
                                                       <textarea name="pengertian" maxLength="160" rows="3" class="form-control" style="resize: none;" required><?php echo $pengertian ?></textarea>
                                                  </div>
                                             </div>
                                             </div>
                                             
                                             <div class="card-body card-block"><div class="row form-group"></div></div>
                                             <div class="row form-group">
                                                  <div class="col col-md-2"></div>
                                                  <div class="col col-md-4">
                                                       <button type="submit" class="role member">Simpan</button>
                                                       &nbsp;&nbsp;&nbsp;
                                                       <a href="<?php echo site_url('gejala') ?>" class="role admin">Batal</a>
                                                  </div>
                                             </div>                                             
                                             </form>
                                        </div>
                                   <?php } ?>
                                </div>                            
                            </div>                            
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="copyright">
                                        <p>Skripsi JTI Polinema - Copyright &copy; 2019 1541180163 Hilmy</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                
            </div>
          </div>
                

     </div>
</body>
</html>