<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!doctype html>
<head>
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <title>Konsultasi - SLB Mumtaz Pujon</title>
     <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
     <link rel="shortcut icon" href="asset/images/icon.png" type="image/png">
     <link rel="stylesheet" href="asset/css/font-awesome.min.css">
     <link rel="stylesheet" href="asset/css/material-design-iconic-font.min.css">
     <link rel="stylesheet" href="asset/css/bootstrap.min.css">
     <link rel="stylesheet" href="asset/css/animsition.min.css">
     <link rel="stylesheet" href="asset/css/bootstrap-progressbar-3.3.4.min.css">
     <link rel="stylesheet" href="asset/css/animate.css">
     <link rel="stylesheet" href="asset/css/hamburgers.min.css">
     <link rel="stylesheet" href="asset/css/slick.css">
     <link rel="stylesheet" href="asset/css/select2.min.css">
     <link rel="stylesheet" href="asset/css/perfect-scrollbar.css">
     <link rel="stylesheet" href="asset/css/theme.css">    
     <link rel="stylesheet" href="asset/css/style.css">
     <script>
          function onClick(e) {
               if (document.getElementById('G'+e).checked==true) {
                    document.getElementById('pilih').value = +document.getElementById('pilih').value + 1;
               }
               else {
                    document.getElementById('pilih').value = +document.getElementById('pilih').value - 1;
               }
          }
          function cek() {
               if (+document.getElementById('pilih').value<3) {
                    alert('Pilih Rules Gejala (min. 3)');
                    return false;
               }

               return;          
          }
     </script>
</head>
<body>
     <div class="page-wrapper">
          <aside class="menu-sidebar d-none d-lg-block">
               <div class="menu-sidebar__content js-scrollbar1">
                    <nav class="navbar-sidebar">
                         <ul class="list-unstyled navbar__list">                            
                              <li><a href="<?php echo site_url('akun') ?>">
                                   <i class="fa fa-user"></i>Akun
                              </a></li>
                              <li><a href="<?php echo site_url('gejala') ?>">
                                   <i class="fa fa-question-circle"></i>Gejala
                              </a></li>
                              <li><a href="<?php echo site_url('konsultasi') ?>">
                                   <i class="fa fa-sort-amount-asc active"></i><i class="active">Konsultasi</i>
                              </a></li>
                              <li><a href="<?php echo site_url('report') ?>">
                                   <i class="fa fa-file-pdf-o"></i>Report
                              </a></li>                            
                         </ul>
                    </nav>
               </div>
          </aside>

          <div class="page-container">
                <header class="header-desktop">
                    <div class="section__content section__content--p30">
                        <div class="container-fluid">
                            <div class="header-wrap">
                                <div class="header-button">
                                    <div class="account-wrap">
                                        <div class="account-item clearfix js-item-menu">
                                            <div class="image"></div>                                        
                                            <div class="content">
                                                <?php echo $this->session->userdata('nama') ?> - <a href="<?php echo site_url('login/out') ?>">Logout</a>
                                            </div>                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>

                <div class="main-content">
                    <div class="section__content section__content--p30">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h2 class="title-1 m-b-16">Konsultasi</h2>
                                    <br />
                                    <?php if (!isset($_GET['p'])) { ?>
                                    <div class="table-responsive table--no-card m-b-40">
                                        <table class="table table-borderless table-striped table-earning">
                                            <thead>
                                                <tr>
                                                    <th>Hasil</th>
                                                    <th>Rules</th>
                                                    <th width="10%" class="text-center">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                  <?php
                                                       $this->db->order_by('IDk', '');
                                                       $sql = $this->db->get('konsultasi');
                                                       foreach ($sql->result() as $row) {
                                                  ?>
                                                  <tr>
                                                       <td><?php echo $row->hasil ?></td>
                                                       <td>
                                                            <?php
                                                                 $rules = '';

                                                                 $this->db->select('gejala.nama AS nama');
                                                                 $this->db->from('konsultasi_dtl'); 
                                                                 $this->db->join('gejala', 'gejala.ID=konsultasi_dtl.IDg', 'left');
                                                                 $this->db->where('konsultasi_dtl.IDkd', $row->IDk);
                                                                 $this->db->order_by('gejala.ID', '');
                                                                 $sqld = $this->db->get();
                                                                 foreach ($sqld->result() as $rowd) {
                                                                      $rules = $rules . $rowd->nama . ' - ';
                                                                 }
                                                                 echo substr($rules,0,strlen($rules)-3)
                                                            ?>
                                                       </td>
                                                       <td class="text-center">
                                                            <button onClick="window.location.href='?p=edit&ID=<?php echo $row->IDk ?>';" class="role member">Edit</button>
                                                            &nbsp;&nbsp;&nbsp;
                                                            <button onClick="window.location.href='<?php echo site_url('konsultasi/delete') ?>?ID=<?php echo $row->IDk ?>';" class="role admin">Hapus</button>
                                                       </td>
                                                  </tr>
                                                  <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <button onClick="window.location.href='?p=tambah';" class="role user">Tambah</button>
                                   <?php } else { ?>
                                        <div class="card">
                                             <?php if ($_GET['p']=='tambah') {
                                                  $IDkd = 0; $hasil = ''; $pilih = 0;
                                             ?>
                                             <?php } else if ($_GET['p']=='edit') {
                                                  $sql = $this->db->get_where('konsultasi', array('IDk' => $_GET['ID']));
                                                  $row = $sql->row();                                                  
                                                  $IDkd = (int)$row->IDk; $hasil = $row->hasil;                                                  
                                                  $sql = $this->db->get_where('konsultasi_dtl', array('IDkd' => $_GET['ID']));
                                                  $pilih = $sql->num_rows();                                                  
                                             ?>
                                             <?php } ?>
                                             <?php if ($_GET['p']=='tambah') { ?>
                                                  <form onsubmit="return cek()" method="post" action="konsultasi/tambah">
                                             <?php } else if ($_GET['p']=='edit') { ?>
                                                  <form onsubmit="return cek()" method="post" action="konsultasi/edit?ID=<?php echo $_GET['ID'] ?>">
                                             <?php } ?>
                                             <div class="card-body card-block">
                                             <div class="row form-group">
                                                  <div class="col col-md-2">
                                                       <label for="text-input" class="form-control-label">Hasil</label>
                                                  </div>
                                                  <div class="col-12 col-md-4">
                                                       <input type="text" name="hasil" value="<?php echo $hasil ?>" maxLength="20" class="form-control" required />
                                                  </div>
                                             </div>
                                             </div>
                                             <div class="card-body card-block">
                                             <div class="row form-group">
                                                  <div class="col col-md-2">
                                                       <label for="text-input" class="form-control-label">Gejala</label>
                                                  </div>
                                                  <div class="col-12 col-md-10">
                                                       <input hidden id="pilih" value="<?php echo $pilih ?>" />
                                                       <?php
                                                            $this->db->order_by('ID', '');
                                                            $sql = $this->db->get('gejala');
                                                            foreach ($sql->result() as $row) {
                                                                 $sqld = $this->db->get_where('konsultasi_dtl', array('IDkd' => $IDkd, 'IDg' => $row->ID));
                                                                 if ($sqld->num_rows()>0) { $chk = 'checked'; } else { $chk = ''; }                                                  
                                                       ?>
                                                       <div class="col-12 col-md-12" style="text-align: left; padding: 0.2em 0em;">
                                                            <input type="checkbox" <?php echo $chk ?> id="G<?php echo $row->ID ?>" onClick="onClick(<?php echo $row->ID ?>)" name="G<?php echo $row->ID ?>" value="<?php echo $row->ID ?>" />&nbsp;&nbsp;
                                                            <?php echo $row->pengertian ?>
                                                       </div>
                                                       <?php } ?>
                                                  </div>
                                             </div>
                                             </div>
                                             <div class="row form-group">
                                                  <div class="col col-md-2"></div>
                                                  <div class="col col-md-4">
                                                       <button type="submit" class="role member">Simpan</button>
                                                       &nbsp;&nbsp;&nbsp;
                                                       <a href="<?php echo site_url('konsultasi') ?>" class="role admin">Batal</a>
                                                  </div>
                                             </div>                                             
                                             </form>
                                        </div>
                                   <?php } ?>
                                </div>                            
                            </div>                            
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="copyright">
                                        <p>Skripsi JTI Polinema - Copyright &copy; 2019 1541180163 Hilmy</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                
            </div>
          </div>
                

     </div>
</body>
</html>